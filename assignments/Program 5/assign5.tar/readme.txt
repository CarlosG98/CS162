Name: Carlos Gonzalez

Description: This program asks a user to input values and stores them in a list using the push_front(int) function. After the user is done inputting values, they are asked if they want to sort their list in ascending or descending order. If they wish to make a new list, they can, else the program exits.

Extra Credit: The program implements the selection sort method to sort list in descending order.
