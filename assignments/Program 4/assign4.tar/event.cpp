/******************************************************
** Program: event.cpp
** Author: Carlos Gonzalez
** Date: 02/14/2020
** Description: function definitions for event class
** Input:
** Output:
******************************************************/
#include "event.h"
#include <iostream>

using namespace std;

Event::Event(int t) : type(t){}